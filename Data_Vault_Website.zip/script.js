
function notPaid(){
 alert("Payment not received yet. Please complete payment first.");
}
function verify(){
 alert("UTR received. Please wait 15-30 minutes for verification.");
}
